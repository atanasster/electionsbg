"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KDTree = exports.Node = void 0;
var quickselect_1 = __importDefault(require("./quickselect"));
var boundedpqueue_1 = require("./boundedpqueue");
// https://github.com/gishi523/kd-tree/blob/master/kdtree.h
var Node = /** @class */ (function () {
    function Node() {
        this.next = [];
    }
    return Node;
}());
exports.Node = Node;
var KDTree = /** @class */ (function () {
    function KDTree(points, dim) {
        this.points = points;
        this.dim = dim;
        this.buildTree();
    }
    KDTree.prototype.buildTree = function () {
        var indices = __spreadArray([], Array(this.points.length), true).map(function (_, i) { return (i); });
        ;
        this.root = this.buildTreeRecurse(indices, this.points.length, 0);
    };
    KDTree.prototype.buildTreeRecurse = function (indices, npoints, depth) {
        var _this = this;
        if (npoints <= 0) {
            return new Node();
        }
        var axis = depth % this.dim;
        var mid = Math.floor((npoints - 1) / 2);
        (0, quickselect_1.default)(indices, mid, 0, npoints - 1, function (lhs, rhs) {
            return _this.points[lhs][axis] < _this.points[rhs][axis] ? -1 : _this.points[lhs][axis] > _this.points[rhs][axis] ? 1 : 0;
        });
        var node = new Node();
        node.index = indices[mid];
        node.axis = axis;
        node.next.push(this.buildTreeRecurse(indices, mid, depth + 1));
        node.next.push(this.buildTreeRecurse(indices.slice(mid + 1), npoints - mid - 1, depth + 1));
        return node;
    };
    KDTree.prototype.knnSearch = function (query, k) {
        var queue = new boundedpqueue_1.BoundedPQueue(k);
        queue = this.knnSearchRecurse(query, this.root, queue, k);
        var indices = new Array();
        for (var i = 0; i < queue.items().length; i++) {
            var max = queue.extractMax();
            if (typeof max !== 'undefined') {
                indices.push(max[1]);
            }
        }
        return indices;
    };
    KDTree.prototype.radiusSearch = function (query, radius) {
        var indices = [];
        this.radiusSearchRecursive(query, this.root, indices, radius);
        return indices;
    };
    KDTree.prototype.distance = function (x, y) {
        var sum2 = 0;
        for (var i = 0; i < x.length; i++) {
            sum2 += (x[i] - y[i]) * (x[i] - y[i]);
        }
        return Math.sqrt(sum2);
    };
    KDTree.prototype.knnSearchRecurse = function (query, node, queue, k) {
        if (typeof node === 'undefined') {
            return queue;
        }
        if (typeof node.index !== 'undefined' && typeof node.axis !== 'undefined') {
            var train = this.points[node.index];
            var dist = this.distance(train, query);
            queue.add(dist, node.index);
            var dir = query[node.axis] < train[node.axis] ? 0 : 1;
            queue = this.knnSearchRecurse(query, node.next[dir], queue, k);
            var diff = Math.abs(query[node.axis] - train[node.axis]);
            if (queue.items().length < k || diff < queue.max()) {
                queue = this.knnSearchRecurse(query, node.next[1 - dir], queue, k);
            }
        }
        return queue;
    };
    KDTree.prototype.radiusSearchRecursive = function (query, node, indices, radius) {
        if (typeof node === 'undefined') {
            return indices;
        }
        if (typeof node.index !== 'undefined' && typeof node.axis !== 'undefined') {
            var train = this.points[node.index];
            var dist = this.distance(train, query);
            if (dist < radius) {
                indices.push(node.index);
            }
            var dir = query[node.axis] < train[node.axis] ? 0 : 1;
            this.radiusSearchRecursive(query, node.next[dir], indices, radius);
            var diff = Math.abs(query[node.axis] - train[node.axis]);
            if (diff < radius) {
                this.radiusSearchRecursive(query, node.next[1 - dir], indices, radius);
            }
        }
        return indices;
    };
    return KDTree;
}());
exports.KDTree = KDTree;
