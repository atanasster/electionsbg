"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoundedPQueue = void 0;
// https://github.com/jhagege/BoundedPriorityQueue/blob/master/bounded_priority_queue.py
var BoundedPQueue = /** @class */ (function () {
    function BoundedPQueue(k) {
        this.heap = [];
        this.k = k;
    }
    BoundedPQueue.prototype.items = function () {
        return this.heap;
    };
    BoundedPQueue.prototype.parent = function (index) {
        return Math.floor(index / 2);
    };
    BoundedPQueue.prototype.leftChild = function (index) {
        return 2 * index + 1;
    };
    BoundedPQueue.prototype.rightChild = function (index) {
        return 2 * index + 2;
    };
    BoundedPQueue.prototype.max = function () {
        return this.heap[0][0];
    };
    BoundedPQueue.prototype.maxHeapify = function (index) {
        var _a;
        var left_index = this.leftChild(index);
        var right_index = this.rightChild(index);
        var largest = index;
        if (left_index < this.heap.length && this.heap[left_index][0] > this.heap[index][0]) {
            largest = left_index;
        }
        if (right_index < this.heap.length && this.heap[right_index][0] > this.heap[index][0]) {
            largest = right_index;
        }
        if (largest != index) {
            _a = [this.heap[largest], this.heap[index]], this.heap[index] = _a[0], this.heap[largest] = _a[1];
            this.maxHeapify(largest);
        }
    };
    BoundedPQueue.prototype.extractMax = function () {
        var max = this.heap[0];
        var data = this.heap.pop();
        if (typeof data !== 'undefined' && this.heap.length > 0) {
            this.heap[0] = data;
            this.maxHeapify(0);
        }
        return max;
    };
    BoundedPQueue.prototype.propagateUp = function (index) {
        var _a;
        var cur_idx = index;
        while (cur_idx != 0 && this.heap[this.parent(cur_idx)][0] < this.heap[cur_idx][0]) {
            _a = [this.heap[this.parent(cur_idx)], this.heap[cur_idx]], this.heap[cur_idx] = _a[0], this.heap[this.parent(cur_idx)] = _a[1];
            cur_idx = this.parent(cur_idx);
        }
    };
    BoundedPQueue.prototype.heapAppend = function (key, value) {
        this.heap.push([key, value]);
        this.propagateUp(this.heap.length - 1);
    };
    BoundedPQueue.prototype.add = function (key, value) {
        var size = this.heap.length;
        if (size == this.k) {
            var max_elem = this.max();
            if (key < max_elem) {
                this.extractMax();
                this.heapAppend(key, value);
            }
        }
        else {
            this.heapAppend(key, value);
        }
    };
    return BoundedPQueue;
}());
exports.BoundedPQueue = BoundedPQueue;
