"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var config = {
    verbose: true,
    transform: {
        "^.+\\.tsx?$": "ts-jest",
    },
};
exports.default = config;
