"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _1 = require("./");
describe('KDTree', function () {
    it('knnSearch', function () {
        var points = [[1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]];
        var tree = new _1.KDTree(points, 3);
        var ans = tree.knnSearch([1.0, 0.0, 0.0], 1);
        expect(ans).toEqual([0]);
    });
    it('radiusSearch', function () {
        var points = [[1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]];
        var tree = new _1.KDTree(points, 3);
        var ans = tree.radiusSearch([1.0, 0.0, 0.0], 0.1);
        expect(ans).toEqual([0]);
        ans = tree.radiusSearch([0.0, 0.0, 1.0], 0.1);
        expect(ans).toEqual([1]);
        ans = tree.radiusSearch([0.0, 1.0, 0.0], 0.1);
        expect(ans).toEqual([2]);
    });
});
